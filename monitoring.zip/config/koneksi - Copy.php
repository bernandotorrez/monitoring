<?php
$con = mysqli_connect("mysql.idhostinger.com","u659197765_root","B3rnando","u659197765_distr");

// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
?>