	<div class="footer">
				<div class="footer-inner">
					<div class="footer-content">
						<span class="bigger-120">
							<span class="blue bolder">Monitoring Proyek</span>
							PT. Malmass Mitra Teknik
						</span>

						&nbsp; &nbsp;
					
					</div>
				</div>
			</div>